# Meu Painel Mental — v4 Design Premium

Versão executada com foco em elevar design, navegação e sensação nativa.

## Principais mudanças

- Removido o menu/banner superior fixo.
- Navegação inferior premium com 5 itens: Hoje, Praticar, Biblioteca, Board e Ajustes.
- Biblioteca centralizada com Afirmações, Crenças, Insights, Temas, Categorias e Busca.
- Design iOS premium + Material You + Liquid Glass sutil.
- Ícones SVG locais, modernos e consistentes, sem emojis.
- Modo escuro AMOLED refinado.
- Cards redesenhados para afirmações, crenças, insights, imagens e práticas.
- Modais estilo sheet nativo, abrindo de baixo para cima.
- TTS filtrando apenas vozes pt-BR.
- Mini player TTS com pausar, continuar, parar, anterior e próxima.
- Prática rápida, prática profunda, revisão por voz e slideshow do Visual Board.
- Inclusão em massa de afirmações, crenças e insights.
- Visual Board com compressão de imagem antes de salvar.
- Backup/exportação JSON e importação com opção de mesclar ou substituir.
- PWA offline-first, sem backend e sem login.

## Publicação no Netlify

Envie o conteúdo deste ZIP para o Netlify. Não há etapa de build.

## Privacidade

Todos os dados são armazenados localmente no navegador do usuário.
