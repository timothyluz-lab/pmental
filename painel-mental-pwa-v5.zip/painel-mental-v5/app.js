(() => {
  "use strict";

  const APP_VERSION = "4.0.0-design-premium";
  const KEY = "painelMentalPwa.v4.designPremium";
  const LEGACY_KEYS = [
    "painelMentalPwa.v3.crencas",
    "painelMentalPwa.v2.premium",
    "painelMentalPwa.v1"
  ];

  const DEFAULT_STATE = {
    settings: {
      appName: "Meu Painel Mental",
      subtitle: "",
      opening: "",
      theme: "auto",
      primary: "#7c3aed",
      accent: "#06b6d4",
      fontScale: 1,
      motion: "on",
      tts: { voiceURI: "", rate: 0.96, pitch: 1, volume: 1 }
    },
    affirmations: [],
    beliefs: [],
    insights: [],
    board: [],
    themes: [],
    categories: [],
    practiceLog: [],
    recent: [],
    ui: { libraryTab: "affirmations", search: "", filters: {} }
  };

  let state = loadState();
  let route = "today";
  let activeFilters = {
    affirmations: { q: "", theme: "", category: "", favorite: false, sort: "recent" },
    beliefs: { q: "", theme: "", category: "", favorite: false, type: "", sort: "recent" },
    insights: { q: "", theme: "", category: "", favorite: false, sort: "recent" },
    board: { q: "", theme: "", category: "", favorite: false, sort: "recent" },
    global: ""
  };

  let voices = [];
  let queue = [];
  let queueIndex = 0;
  let currentUtterance = null;
  let playerState = { playing: false, paused: false, title: "", subtitle: "" };
  let slideshowIndex = 0;

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
  const main = $("#main");
  const sheetBackdrop = $("#sheetBackdrop");
  const sheetBody = $("#sheetBody");
  const sheetTitle = $("#sheetTitle");
  const sheetKicker = $("#sheetKicker");
  const miniPlayer = $("#miniPlayer");
  const toastEl = $("#toast");

  const icons = {
    plus: "i-plus", play: "i-play", pause: "i-pause", stop: "i-stop", next: "i-next", prev: "i-prev",
    quote: "i-quote", belief: "i-belief", bulb: "i-bulb", image: "i-image", search: "i-search",
    star: "i-star", edit: "i-edit", trash: "i-trash", tag: "i-tag", volume: "i-volume", upload: "i-upload", download: "i-download"
  };

  function esc(v = "") {
    return String(v)
      .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;").replaceAll("'", "&#039;");
  }
  function id() { return crypto?.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
  function todayIso() { return new Date().toISOString().slice(0, 10); }
  function nowIso() { return new Date().toISOString(); }
  function clone(obj) { return JSON.parse(JSON.stringify(obj)); }

  function deepMerge(target, source) {
    for (const key of Object.keys(source || {})) {
      if (source[key] && typeof source[key] === "object" && !Array.isArray(source[key])) {
        target[key] = deepMerge(target[key] || {}, source[key]);
      } else {
        target[key] = source[key];
      }
    }
    return target;
  }

  function loadState() {
    try {
      let raw = localStorage.getItem(KEY);
      if (!raw) {
        for (const k of LEGACY_KEYS) {
          raw = localStorage.getItem(k);
          if (raw) break;
        }
      }
      const loaded = raw ? JSON.parse(raw) : {};
      const merged = deepMerge(clone(DEFAULT_STATE), loaded);
      merged.beliefs = merged.beliefs || merged.crencas || [];
      merged.insights = merged.insights || [];
      merged.themes = merged.themes || [];
      merged.categories = merged.categories || [];
      return merged;
    } catch {
      return clone(DEFAULT_STATE);
    }
  }

  function save() {
    localStorage.setItem(KEY, JSON.stringify(state));
    applySettings();
  }

  function applySettings() {
    document.title = state.settings.appName || "Meu Painel Mental";
    document.documentElement.dataset.theme = state.settings.theme || "auto";
    document.documentElement.dataset.motion = state.settings.motion || "on";
    document.documentElement.style.setProperty("--primary", state.settings.primary || "#7c3aed");
    document.documentElement.style.setProperty("--accent", state.settings.accent || "#06b6d4");
    document.documentElement.style.setProperty("--fs", state.settings.fontScale || 1);
    $("meta[name='theme-color']")?.setAttribute("content", state.settings.theme === "light" ? "#f7f7fb" : "#030409");
  }

  function toast(message) {
    toastEl.textContent = message;
    toastEl.classList.add("show");
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(() => toastEl.classList.remove("show"), 2400);
  }

  function hIcon(name, cls = "") {
    return `<span class="i ${icons[name] || name} ${cls}" aria-hidden="true"></span>`;
  }

  function setRoute(next) {
    route = next;
    $$("#bottomNav button").forEach(b => b.classList.toggle("active", b.dataset.route === route));
    render();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function render() {
    applySettings();
    if (route === "today") renderToday();
    if (route === "practice") renderPractice();
    if (route === "library") renderLibrary();
    if (route === "board") renderBoard();
    if (route === "settings") renderSettings();
    renderMiniPlayer();
  }

  function randomOf(arr) {
    return arr.length ? arr[Math.floor(Math.random() * arr.length)] : null;
  }

  function stats() {
    return {
      affirmations: state.affirmations.length,
      beliefs: state.beliefs.length,
      insights: state.insights.length,
      board: state.board.length,
      themes: state.themes.length,
      categories: state.categories.length,
      practices: state.practiceLog.length,
      streak: calcStreak()
    };
  }

  function calcStreak() {
    const days = new Set(state.practiceLog.map(x => x.date));
    let count = 0;
    const d = new Date();
    for (;;) {
      const iso = d.toISOString().slice(0, 10);
      if (!days.has(iso)) break;
      count++;
      d.setDate(d.getDate() - 1);
    }
    return count;
  }

  function renderToday() {
    const s = stats();
    const aff = randomOf(state.affirmations);
    const belief = randomOf(state.beliefs);
    const insight = randomOf(state.insights);
    const img = randomOf(state.board);
    const dateLabel = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });
    main.innerHTML = `
      <section class="view">
        <article class="hero-card">
          <div class="hero-content">
            <p class="kicker">${dateLabel}</p>
            <h1 class="hero-title">${esc(state.settings.appName)}</h1>
            ${state.settings.opening ? `<p class="hero-sub">${esc(state.settings.opening)}</p>` : ""}
            <div class="hero-actions">
              <button class="primary-btn" data-action="start-quick">${hIcon("play")}Começar prática</button>
              <button class="ghost-btn" data-action="speak-today">${hIcon("volume")}Ouvir destaque</button>
              <button class="ghost-btn" data-route-jump="library">${hIcon("library")}Biblioteca</button>
            </div>
            <div class="stat-grid">
              <div class="stat"><strong>${s.affirmations}</strong><small>afirmações</small></div>
              <div class="stat"><strong>${s.beliefs}</strong><small>crenças</small></div>
              <div class="stat"><strong>${s.insights}</strong><small>insights</small></div>
              <div class="stat"><strong>${s.streak}</strong><small>dias seguidos</small></div>
            </div>
          </div>
        </article>

        <section class="section">
          <div class="section-head">
            <div><h2>Destaques</h2></div>
            <button class="ghost-btn" data-action="log-practice">${hIcon("star")}Registrar</button>
          </div>
          <div class="grid two">
            ${aff ? affirmationCard(aff, true) : emptyMini("quote", "Sem afirmações", "Inclua sua primeira afirmação.")}
            ${belief ? beliefCard(belief, true) : emptyMini("belief", "Sem crenças", "Mapeie uma crença para transformar.")}
            ${insight ? insightCard(insight, true) : emptyMini("bulb", "Sem insights", "Guarde aprendizados importantes.")}
            ${img ? imageHighlight(img) : emptyMini("image", "Sem imagens", "Adicione imagens ao Visual Board.")}
          </div>
        </section>
      </section>`;
  }

  function renderPractice() {
    main.innerHTML = `
      <section class="view">
        ${screenTitle("Praticar", "", `
          <button class="primary-btn" data-action="start-quick">${hIcon("play")}Sessão rápida</button>
        `)}
        <div class="grid three">
          ${practiceCard("Prática rápida", "2 min", "3 afirmações + 1 registro.", "start-quick", "play")}
          ${practiceCard("Reprogramação profunda", "10 min", "Crença, afirmações e visualização.", "start-deep", "belief")}
          ${practiceCard("Ouvir afirmações", "Áudio", "TTS com vozes pt-BR.", "speak-filtered-affirmations", "volume")}
          ${practiceCard("Revisar crenças", "Foco", "Leia e ouça crenças em transição.", "speak-beliefs", "belief")}
          ${practiceCard("Visualização", "Board", "Slideshow das imagens cadastradas.", "start-slideshow", "image")}
          ${practiceCard("Sessão noturna", "Calma", "Ritmo lento, TTS suave.", "night-session", "star")}
        </div>

        <section class="section">
          <div class="section-head"><div><h2>Progresso</h2></div></div>
          <div class="stat-grid">
            <div class="stat"><strong>${state.practiceLog.length}</strong><small>práticas totais</small></div>
            <div class="stat"><strong>${calcStreak()}</strong><small>sequência atual</small></div>
            <div class="stat"><strong>${new Set(state.practiceLog.map(x => x.date)).size}</strong><small>dias ativos</small></div>
            <div class="stat"><strong>${todayIso()}</strong><small>hoje</small></div>
          </div>
        </section>
      </section>`;
  }

  function practiceCard(title, time, desc, action, icon) {
    return `<article class="card">
      <p class="kicker">${esc(time)}</p>
      <h3>${hIcon(icon, "i-lg")} ${esc(title)}</h3>
      <p>${esc(desc)}</p>
      <div class="card-actions"><button class="primary-btn" data-action="${action}">${hIcon("play")}Iniciar</button></div>
    </article>`;
  }

  function renderLibrary() {
    const tab = state.ui.libraryTab || "affirmations";
    main.innerHTML = `
      <section class="view">
        ${screenTitle("Biblioteca", "", `
          <button class="primary-btn" data-action="quick-add">${hIcon("plus")}Adicionar</button>
        `)}
        <div class="segmented" role="tablist">
          ${seg("affirmations", "Afirmações", "quote", tab)}
          ${seg("beliefs", "Crenças", "belief", tab)}
          ${seg("insights", "Insights", "bulb", tab)}
          ${seg("themes", "Temas", "tag", tab)}
          ${seg("categories", "Categorias", "tag", tab)}
          ${seg("search", "Busca", "search", tab)}
        </div>
        <div id="libraryContent">${renderLibraryContent(tab)}</div>
      </section>`;
  }

  function seg(name, label, icon, tab) {
    return `<button class="chip ${tab === name ? "active" : ""}" data-library-tab="${name}">${hIcon(icon)}${label}</button>`;
  }

  function renderLibraryContent(tab) {
    if (tab === "affirmations") return listAffirmations();
    if (tab === "beliefs") return listBeliefs();
    if (tab === "insights") return listInsights();
    if (tab === "themes") return listThemes();
    if (tab === "categories") return listCategories();
    if (tab === "search") return globalSearch();
    return "";
  }

  function filterToolbar(kind, extra = "") {
    const f = activeFilters[kind];
    return `<div class="section">
      <div class="search-row">
        <label class="search">
          ${hIcon("search")}
          <input type="search" data-filter-q="${kind}" value="${esc(f.q)}" placeholder="Buscar..." />
        </label>
        <button class="chip ${f.favorite ? "active" : ""}" data-filter-fav="${kind}">${hIcon("star")}Favoritos</button>
        ${extra}
      </div>
      <div class="filters" style="margin-top:10px">
        ${selectChip(kind, "theme", "Todos os temas", state.themes, f.theme)}
        ${selectChip(kind, "category", "Todas as categorias", state.categories, f.category)}
        ${selectChip(kind, "sort", "Ordenar", ["recent|Recentes", "old|Antigos", "title|Título", "favorite|Favoritos"], f.sort)}
      </div>
    </div>`;
  }

  function selectChip(kind, field, placeholder, values, selected) {
    const opts = [`<option value="">${placeholder}</option>`].concat(values.map(v => {
      let value = v, label = v;
      if (String(v).includes("|")) [value, label] = String(v).split("|");
      return `<option value="${esc(value)}" ${value === selected ? "selected" : ""}>${esc(label)}</option>`;
    }));
    return `<select class="chip" data-filter-select="${kind}:${field}">${opts.join("")}</select>`;
  }

  function listAffirmations() {
    const items = filterItems(state.affirmations, activeFilters.affirmations);
    return `
      <div class="section-head" style="margin-top:16px">
        <div><h2>Afirmações</h2></div>
        <div class="title-actions">
          <button class="ghost-btn" data-action="bulk-affirmations">${hIcon("upload")}Massa</button>
          <button class="primary-btn" data-action="add-affirmation">${hIcon("plus")}Nova</button>
        </div>
      </div>
      ${filterToolbar("affirmations")}
      ${items.length ? `<div class="grid two section">${items.map(x => affirmationCard(x)).join("")}</div>` : emptyState("quote", "Nenhuma afirmação", "Inclua uma afirmação ou use a inclusão em massa.", "Criar afirmação", "add-affirmation")}`;
  }

  function listBeliefs() {
    const f = activeFilters.beliefs;
    const extra = `<select class="chip" data-filter-select="beliefs:type">
      <option value="">Todos os tipos</option>
      <option value="limitante" ${f.type === "limitante" ? "selected" : ""}>Limitante</option>
      <option value="transicao" ${f.type === "transicao" ? "selected" : ""}>Em transição</option>
      <option value="fortalecedora" ${f.type === "fortalecedora" ? "selected" : ""}>Fortalecedora</option>
    </select>`;
    const items = filterItems(state.beliefs, f);
    return `
      <div class="section-head" style="margin-top:16px">
        <div><h2>Crenças</h2></div>
        <div class="title-actions">
          <button class="ghost-btn" data-action="bulk-beliefs">${hIcon("upload")}Massa</button>
          <button class="primary-btn" data-action="add-belief">${hIcon("plus")}Nova</button>
        </div>
      </div>
      ${filterToolbar("beliefs", extra)}
      ${items.length ? `<div class="grid two section">${items.map(x => beliefCard(x)).join("")}</div>` : emptyState("belief", "Nenhuma crença", "Mapeie uma crença limitante e escolha a crença fortalecedora que vai substituí-la.", "Mapear crença", "add-belief")}`;
  }

  function listInsights() {
    const items = filterItems(state.insights, activeFilters.insights);
    return `
      <div class="section-head" style="margin-top:16px">
        <div><h2>Insights</h2></div>
        <div class="title-actions">
          <button class="ghost-btn" data-action="bulk-insights">${hIcon("upload")}Massa</button>
          <button class="primary-btn" data-action="add-insight">${hIcon("plus")}Novo</button>
        </div>
      </div>
      ${filterToolbar("insights")}
      ${items.length ? `<div class="grid two section">${items.map(x => insightCard(x)).join("")}</div>` : emptyState("bulb", "Nenhum insight", "Guarde ideias, princípios e lembretes que você quer revisar.", "Criar insight", "add-insight")}`;
  }

  function listThemes() {
    const themes = unique([...state.themes, ...allItems().map(x => x.theme).filter(Boolean)]);
    return `
      <div class="section-head" style="margin-top:16px">
        <div><h2>Temas</h2></div>
        <button class="primary-btn" data-action="add-theme">${hIcon("plus")}Novo tema</button>
      </div>
      ${themes.length ? `<div class="grid two section">${themes.map(t => taxonomyCard(t, "theme")).join("")}</div>` : emptyState("tag", "Nenhum tema", "Crie temas para organizar seu banco por áreas da vida.", "Criar tema", "add-theme")}`;
  }

  function listCategories() {
    const cats = unique([...state.categories, ...allItems().map(x => x.category).filter(Boolean)]);
    return `
      <div class="section-head" style="margin-top:16px">
        <div><h2>Categorias</h2></div>
        <button class="primary-btn" data-action="add-category">${hIcon("plus")}Nova categoria</button>
      </div>
      ${cats.length ? `<div class="grid two section">${cats.map(t => taxonomyCard(t, "category")).join("")}</div>` : emptyState("tag", "Nenhuma categoria", "Crie categorias para filtrar e praticar com mais precisão.", "Criar categoria", "add-category")}`;
  }

  function globalSearch() {
    const q = activeFilters.global;
    const affs = q ? filterItems(state.affirmations, { q, sort: "recent" }) : [];
    const beliefs = q ? filterItems(state.beliefs, { q, sort: "recent" }) : [];
    const insights = q ? filterItems(state.insights, { q, sort: "recent" }) : [];
    const board = q ? filterItems(state.board, { q, sort: "recent" }) : [];
    return `
      <div class="section">
        <label class="search">
          ${hIcon("search")}
          <input type="search" id="globalSearch" value="${esc(q)}" placeholder="Buscar em todo o app..." autofocus />
        </label>
      </div>
      ${q ? `
        <div class="card section"><strong>${affs.length + beliefs.length + insights.length + board.length}</strong> resultado(s) para “${esc(q)}”.</div>
        <div class="grid two section">
          ${affs.map(x => affirmationCard(x, true)).join("")}
          ${beliefs.map(x => beliefCard(x, true)).join("")}
          ${insights.map(x => insightCard(x, true)).join("")}
          ${board.map(x => imageHighlight(x)).join("")}
        </div>` : emptyState("search", "Busca global", "Pesquise afirmações, crenças, insights, temas, categorias, tags e imagens.", "", "")}`;
  }

  function renderBoard() {
    const items = filterItems(state.board, activeFilters.board);
    main.innerHTML = `
      <section class="view">
        ${screenTitle("Visual Board", "", `
          <button class="ghost-btn" data-action="start-slideshow">${hIcon("play")}Slideshow</button>
          <button class="primary-btn" data-action="add-image">${hIcon("plus")}Imagem</button>
        `)}
        ${filterToolbar("board")}
        ${items.length ? `<div class="board-grid section">${items.map(imageCard).join("")}</div>` : emptyState("image", "Seu Visual Board está vazio", "Adicione imagens que representem objetivos, estados desejados, viagens, corpo, casa, carreira e sonhos.", "Adicionar imagem", "add-image")}
      </section>`;
  }

  function renderSettings() {
    const s = state.settings;
    const ptbrVoices = getPtBrVoices();
    main.innerHTML = `
      <section class="view">
        ${screenTitle("Ajustes", "", ``)}
        <div class="grid two">
          <section class="card">
            <h3>Identidade</h3>
            <div class="form-grid">
              ${field("appName", "Nome do app", s.appName)}
              ${field("subtitle", "Subtítulo", s.subtitle)}
              ${textarea("opening", "Frase de abertura", s.opening)}
            </div>
          </section>

          <section class="card">
            <h3>Design</h3>
            <div class="form-grid">
              <div class="field"><label>Tema</label><select id="themeField">
                ${opt("auto", "Automático", s.theme)}
                ${opt("light", "Claro premium", s.theme)}
                ${opt("dark", "Escuro AMOLED", s.theme)}
              </select></div>
              <div class="field"><label>Movimento</label><select id="motionField">
                ${opt("on", "Animações suaves", s.motion)}
                ${opt("off", "Reduzir movimento", s.motion)}
              </select></div>
              <div class="field"><label>Cor principal</label><div class="color-row">
                ${["#7c3aed","#6366f1","#2563eb","#06b6d4","#10b981","#f59e0b","#ef4444","#ec4899","#111827","#000000"].map(c => `<button class="color-dot ${s.primary === c ? "active" : ""}" style="background:${c}" data-color="${c}" aria-label="Cor ${c}"></button>`).join("")}
              </div></div>
              <div class="field"><label>Tamanho da fonte</label><input id="fontScaleField" type="range" min=".9" max="1.2" step=".02" value="${s.fontScale}"></div>
            </div>
          </section>

          <section class="card">
            <h3>Voz (TTS pt-BR)</h3>
            <div class="form-grid" style="margin-top:14px">
              <div class="field"><label>Voz brasileira disponível</label><select id="ttsVoiceField">
                <option value="">Voz padrão do sistema</option>
                ${ptbrVoices.map(v => `<option value="${esc(v.voiceURI)}" ${v.voiceURI === s.tts.voiceURI ? "selected" : ""}>${esc(v.name)} — ${esc(v.lang)}</option>`).join("")}
              </select></div>
              ${ptbrVoices.length ? "" : `<div class="card"><p>Nenhuma voz pt-BR foi detectada neste navegador. Instale/ative voz em português do Brasil no sistema para melhorar a leitura.</p></div>`}
              <div class="form-row">
                <div class="field"><label>Velocidade</label><input id="ttsRateField" type="range" min=".65" max="1.35" step=".01" value="${s.tts.rate}"></div>
                <div class="field"><label>Tom</label><input id="ttsPitchField" type="range" min=".7" max="1.3" step=".01" value="${s.tts.pitch}"></div>
              </div>
              <div class="field"><label>Volume</label><input id="ttsVolumeField" type="range" min=".2" max="1" step=".05" value="${s.tts.volume}"></div>
              <button class="primary-btn" data-action="test-tts">${hIcon("volume")}Testar voz</button>
            </div>
          </section>

          <section class="card">
            <h3>Dados</h3>
            <p>Tudo fica local neste navegador. Sem login, backend ou rastreamento.</p>
            <div class="card-actions">
              <button class="primary-btn" data-action="export-all">${hIcon("download")}Exportar tudo</button>
              <button class="ghost-btn" data-action="import-json">${hIcon("upload")}Importar</button>
              <input id="importFile" type="file" accept="application/json" hidden>
              <button class="danger-btn" data-action="wipe">${hIcon("trash")}Apagar tudo</button>
            </div>
          </section>
        </div>
      </section>`;
  }

  function screenTitle(title, desc, actions = "") {
    return `<header class="screen-title">
      <div><h1>${esc(title)}</h1>${desc ? `<p>${esc(desc)}</p>` : ""}</div>
      ${actions ? `<div class="title-actions">${actions}</div>` : ""}
    </header>`;
  }

  function emptyMini(icon, title, text) {
    return `<article class="card"><h3>${hIcon(icon, "i-lg")} ${esc(title)}</h3><p>${esc(text)}</p></article>`;
  }

  function emptyState(icon, title, text, btnText, action) {
    return `<div class="empty section">
      <div class="empty-icon">${hIcon(icon, "i-lg")}</div>
      <h3>${esc(title)}</h3>
      <p>${esc(text)}</p>
      ${btnText ? `<button class="primary-btn" data-action="${action}">${hIcon("plus")}${esc(btnText)}</button>` : ""}
    </div>`;
  }

  function meta(item) {
    return `<div class="meta">
      ${item.theme ? `<span class="pill theme">${esc(item.theme)}</span>` : ""}
      ${item.category ? `<span class="pill">${esc(item.category)}</span>` : ""}
      ${(item.tags || []).map(t => `<span class="pill">#${esc(t)}</span>`).join("")}
      ${item.favorite ? `<span class="pill theme">${hIcon("star")}Favorito</span>` : ""}
    </div>`;
  }

  function affirmationCard(item, compact = false) {
    return `<article class="card">
      <p class="kicker">Afirmação</p>
      <h3>${esc(item.title || "Afirmação")}</h3>
      <div class="quote-text">${esc(item.text || "")}</div>
      ${meta(item)}
      <div class="card-actions">
        <button class="primary-btn" data-speak-affirmation="${item.id}">${hIcon("volume")}Ouvir</button>
        ${compact ? "" : `
          <button class="ghost-btn" data-fav="affirmations:${item.id}">${hIcon("star")}</button>
          <button class="ghost-btn" data-edit="affirmation:${item.id}">${hIcon("edit")}</button>
          <button class="danger-btn" data-del="affirmations:${item.id}">${hIcon("trash")}</button>
        `}
      </div>
    </article>`;
  }

  function beliefCard(item, compact = false) {
    const intensity = Math.max(0, Math.min(10, Number(item.intensity || 0))) * 10;
    return `<article class="card">
      <p class="kicker">Crença · ${esc(labelBeliefType(item.type))}</p>
      <h3>${esc(item.title || item.current || "Crença")}</h3>
      <div class="belief-pair">
        <div class="belief-line"><b>Atual</b>${esc(item.current || "Não informado")}</div>
        <div class="belief-line"><b>Nova escolha</b>${esc(item.newBelief || "Não informado")}</div>
      </div>
      <div class="intensity" title="Intensidade"><span style="width:${intensity}%"></span></div>
      ${meta(item)}
      <div class="card-actions">
        <button class="primary-btn" data-speak-belief="${item.id}">${hIcon("volume")}Ouvir</button>
        ${compact ? "" : `
          <button class="ghost-btn" data-fav="beliefs:${item.id}">${hIcon("star")}</button>
          <button class="ghost-btn" data-edit="belief:${item.id}">${hIcon("edit")}</button>
          <button class="danger-btn" data-del="beliefs:${item.id}">${hIcon("trash")}</button>
        `}
      </div>
    </article>`;
  }

  function insightCard(item, compact = false) {
    return `<article class="card">
      <p class="kicker">Insight</p>
      <h3>${esc(item.title || "Insight")}</h3>
      <p>${esc(item.text || "")}</p>
      ${meta(item)}
      <div class="card-actions">
        <button class="primary-btn" data-speak-insight="${item.id}">${hIcon("volume")}Ouvir</button>
        ${compact ? "" : `
          <button class="ghost-btn" data-fav="insights:${item.id}">${hIcon("star")}</button>
          <button class="ghost-btn" data-edit="insight:${item.id}">${hIcon("edit")}</button>
          <button class="danger-btn" data-del="insights:${item.id}">${hIcon("trash")}</button>
        `}
      </div>
    </article>`;
  }

  function imageCard(item) {
    return `<article class="card board-card">
      <img class="board-img" src="${item.image}" alt="${esc(item.title || "Imagem")}" loading="lazy">
      <div class="board-body">
        <p class="kicker">${esc(item.theme || item.category || "Visual Board")}</p>
        <h3>${esc(item.title || "Imagem")}</h3>
        <p>${esc(item.description || "")}</p>
        ${meta(item)}
        <div class="card-actions">
          <button class="primary-btn" data-view-image="${item.id}">${hIcon("image")}Abrir</button>
          <button class="ghost-btn" data-fav="board:${item.id}">${hIcon("star")}</button>
          <button class="ghost-btn" data-edit="image:${item.id}">${hIcon("edit")}</button>
          <button class="danger-btn" data-del="board:${item.id}">${hIcon("trash")}</button>
        </div>
      </div>
    </article>`;
  }

  function imageHighlight(item) {
    return `<article class="card board-card">
      <img class="board-img" src="${item.image}" alt="${esc(item.title || "Imagem")}" loading="lazy">
      <div class="board-body"><h3>${esc(item.title || "Imagem do dia")}</h3><p>${esc(item.description || "")}</p></div>
    </article>`;
  }

  function taxonomyCard(name, type) {
    const counts = {
      aff: state.affirmations.filter(x => x[type] === name).length,
      bel: state.beliefs.filter(x => x[type] === name).length,
      ins: state.insights.filter(x => x[type] === name).length,
      img: state.board.filter(x => x[type] === name).length,
    };
    return `<article class="card">
      <p class="kicker">${type === "theme" ? "Tema" : "Categoria"}</p>
      <h3>${esc(name)}</h3>
      <p>${counts.aff} afirmação(ões) · ${counts.bel} crença(s) · ${counts.ins} insight(s) · ${counts.img} imagem(ns)</p>
      <div class="card-actions">
        <button class="ghost-btn" data-tax-filter="${type}:${esc(name)}">${hIcon("search")}Filtrar</button>
        <button class="danger-btn" data-tax-delete="${type}:${esc(name)}">${hIcon("trash")}Excluir</button>
      </div>
    </article>`;
  }

  function labelBeliefType(t) {
    return ({ limitante: "limitante", transicao: "em transição", fortalecedora: "fortalecedora" })[t] || "em revisão";
  }

  function allItems() {
    return [...state.affirmations, ...state.beliefs, ...state.insights, ...state.board];
  }

  function unique(values) {
    return [...new Set(values.map(x => String(x || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  }

  function filterItems(items, f = {}) {
    let out = [...items];
    const q = String(f.q || "").toLowerCase().trim();
    if (q) {
      out = out.filter(x => [
        x.title, x.text, x.current, x.newBelief, x.trigger, x.root, x.script,
        x.description, x.theme, x.category, (x.tags || []).join(" ")
      ].join(" ").toLowerCase().includes(q));
    }
    if (f.theme) out = out.filter(x => x.theme === f.theme);
    if (f.category) out = out.filter(x => x.category === f.category);
    if (f.favorite) out = out.filter(x => x.favorite);
    if (f.type) out = out.filter(x => x.type === f.type);
    const sort = f.sort || "recent";
    out.sort((a, b) => {
      if (sort === "old") return new Date(a.createdAt || 0) - new Date(b.createdAt || 0);
      if (sort === "title") return String(a.title || a.current || "").localeCompare(String(b.title || b.current || ""), "pt-BR");
      if (sort === "favorite") return Number(b.favorite) - Number(a.favorite) || new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0);
      return new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0);
    });
    return out;
  }

  function openSheet(title, kicker, html) {
    sheetTitle.textContent = title;
    sheetKicker.textContent = kicker;
    sheetBody.innerHTML = html;
    sheetBackdrop.hidden = false;
    setTimeout(() => sheetBody.querySelector("input, textarea, select, button")?.focus(), 60);
  }

  function closeSheet() {
    sheetBackdrop.hidden = true;
    sheetBody.innerHTML = "";
  }

  function opt(value, label, selected) {
    return `<option value="${esc(value)}" ${value === selected ? "selected" : ""}>${esc(label)}</option>`;
  }
  function field(name, label, value = "", type = "text") {
    return `<div class="field"><label>${esc(label)}</label><input name="${name}" id="${name}Field" type="${type}" value="${esc(value)}"></div>`;
  }
  function textarea(name, label, value = "") {
    return `<div class="field"><label>${esc(label)}</label><textarea name="${name}" id="${name}Field">${esc(value)}</textarea></div>`;
  }
  function taxFields(item = {}) {
    return `<div class="form-row">
      ${field("theme", "Tema", item.theme || "")}
      ${field("category", "Categoria", item.category || "")}
    </div>
    ${field("tags", "Tags separadas por vírgula", (item.tags || []).join(", "))}`;
  }

  function affirmationForm(item = null) {
    openSheet(item ? "Editar afirmação" : "Nova afirmação", "Afirmações", `
      <form class="form-grid" id="affirmationForm">
        <input type="hidden" name="id" value="${esc(item?.id || "")}">
        ${field("title", "Título", item?.title || "")}
        ${textarea("text", "Texto da afirmação", item?.text || "")}
        ${taxFields(item || {})}
        <label class="chip"><input type="checkbox" name="favorite" ${item?.favorite ? "checked" : ""}> Favorito</label>
        <button class="primary-btn" type="submit">${hIcon("plus")}Salvar afirmação</button>
      </form>`);
  }

  function bulkAffirmationsForm() {
    openSheet("Inclusão em massa", "Afirmações", `
      <form class="form-grid" id="bulkAffirmationsForm">
        <div class="field"><label>Cole uma afirmação por linha</label><textarea name="bulk" style="min-height:240px" placeholder="Eu ajo com calma e firmeza.&#10;Minha mente trabalha a meu favor."></textarea></div>
        <div class="form-row">${field("theme", "Tema para todas", "")}${field("category", "Categoria para todas", "")}</div>
        ${field("tags", "Tags para todas", "")}
        <div class="field"><label>Separação</label><select name="mode">
          <option value="lines">Uma afirmação por linha</option>
          <option value="blocks">Blocos separados por linha em branco</option>
          <option value="semicolon">Ponto e vírgula</option>
        </select></div>
        <button class="primary-btn" type="submit">${hIcon("upload")}Importar</button>
      </form>`);
  }

  function beliefForm(item = null) {
    openSheet(item ? "Editar crença" : "Nova crença", "Crenças", `
      <form class="form-grid" id="beliefForm">
        <input type="hidden" name="id" value="${esc(item?.id || "")}">
        ${field("title", "Título", item?.title || "")}
        <div class="field"><label>Tipo</label><select name="type">
          ${opt("limitante", "Limitante", item?.type || "transicao")}
          ${opt("transicao", "Em transição", item?.type || "transicao")}
          ${opt("fortalecedora", "Fortalecedora", item?.type || "transicao")}
        </select></div>
        ${textarea("current", "Crença atual", item?.current || "")}
        ${textarea("newBelief", "Nova crença escolhida", item?.newBelief || "")}
        ${textarea("trigger", "Gatilho / situação", item?.trigger || "")}
        ${textarea("root", "Crença raiz / interpretação profunda", item?.root || "")}
        ${textarea("evidenceOld", "Evidências contra a crença antiga", item?.evidenceOld || "")}
        ${textarea("evidenceNew", "Evidências da nova crença", item?.evidenceNew || "")}
        ${textarea("script", "Script de instalação", item?.script || "")}
        <div class="field"><label>Intensidade percebida: <span id="intLabel">${item?.intensity || 5}</span>/10</label><input name="intensity" id="intensityInput" type="range" min="0" max="10" step="1" value="${item?.intensity || 5}"></div>
        ${taxFields(item || {})}
        <label class="chip"><input type="checkbox" name="favorite" ${item?.favorite ? "checked" : ""}> Favorito</label>
        <button class="primary-btn" type="submit">${hIcon("plus")}Salvar crença</button>
      </form>`);
  }

  function bulkBeliefsForm() {
    openSheet("Crenças em massa", "Importação", `
      <form class="form-grid" id="bulkBeliefsForm">
        <div class="field"><label>Formato: crença antiga => nova crença</label><textarea name="bulk" style="min-height:240px" placeholder="Eu sempre procrastino => Eu começo pequeno e volto rápido ao eixo&#10;Eu não consigo ganhar dinheiro => Eu aprendo a criar valor e receber melhor"></textarea></div>
        <div class="form-row">${field("theme", "Tema para todas", "")}${field("category", "Categoria para todas", "")}</div>
        ${field("tags", "Tags para todas", "")}
        <button class="primary-btn" type="submit">${hIcon("upload")}Importar crenças</button>
      </form>`);
  }

  function insightForm(item = null) {
    openSheet(item ? "Editar insight" : "Novo insight", "Insights", `
      <form class="form-grid" id="insightForm">
        <input type="hidden" name="id" value="${esc(item?.id || "")}">
        ${field("title", "Título", item?.title || "")}
        ${textarea("text", "Texto do insight", item?.text || "")}
        ${taxFields(item || {})}
        <label class="chip"><input type="checkbox" name="favorite" ${item?.favorite ? "checked" : ""}> Favorito</label>
        <button class="primary-btn" type="submit">${hIcon("plus")}Salvar insight</button>
      </form>`);
  }

  function bulkInsightsForm() {
    openSheet("Insights em massa", "Importação", `
      <form class="form-grid" id="bulkInsightsForm">
        <div class="field"><label>Um insight por linha ou bloco</label><textarea name="bulk" style="min-height:240px" placeholder="Disciplina começa quando a ação é pequena o bastante para ser feita hoje.&#10;&#10;A mente acredita mais em evidência repetida do que em promessa."></textarea></div>
        <div class="form-row">${field("theme", "Tema para todos", "")}${field("category", "Categoria para todos", "")}</div>
        ${field("tags", "Tags para todos", "")}
        <div class="field"><label>Separação</label><select name="mode"><option value="blocks">Blocos por linha em branco</option><option value="lines">Uma linha por insight</option></select></div>
        <button class="primary-btn" type="submit">${hIcon("upload")}Importar insights</button>
      </form>`);
  }

  function imageForm(item = null) {
    openSheet(item ? "Editar imagem" : "Nova imagem", "Visual Board", `
      <form class="form-grid" id="imageForm">
        <input type="hidden" name="id" value="${esc(item?.id || "")}">
        ${field("title", "Título", item?.title || "")}
        ${textarea("description", "Descrição", item?.description || "")}
        ${taxFields(item || {})}
        <div class="field"><label>Imagem ${item ? "(opcional para trocar)" : ""}</label><input name="image" type="file" accept="image/*" ${item ? "" : "required"}></div>
        ${item?.image ? `<img class="board-img" src="${item.image}" alt="Imagem atual">` : ""}
        <label class="chip"><input type="checkbox" name="favorite" ${item?.favorite ? "checked" : ""}> Favorito</label>
        <button class="primary-btn" type="submit">${hIcon("plus")}Salvar imagem</button>
      </form>`);
  }

  function taxonomyForm(type) {
    openSheet(type === "theme" ? "Novo tema" : "Nova categoria", "Organização", `
      <form class="form-grid" id="taxonomyForm" data-type="${type}">
        ${field("name", type === "theme" ? "Nome do tema" : "Nome da categoria", "")}
        <button class="primary-btn" type="submit">${hIcon("plus")}Criar</button>
      </form>`);
  }

  function parseTags(v) {
    return String(v || "").split(",").map(t => t.trim()).filter(Boolean);
  }

  function addTax(item) {
    if (item.theme && !state.themes.includes(item.theme)) state.themes.push(item.theme);
    if (item.category && !state.categories.includes(item.category)) state.categories.push(item.category);
  }

  function splitBulk(text, mode) {
    let parts = mode === "blocks" ? text.split(/\n\s*\n/g) : mode === "semicolon" ? text.split(";") : text.split(/\n/g);
    return parts.map(x => x.replace(/^\s*[-•\d.)]+\s*/, "").trim()).filter(Boolean);
  }

  function quickAdd() {
    const tab = state.ui.libraryTab || "affirmations";
    if (tab === "beliefs") beliefForm();
    else if (tab === "insights") insightForm();
    else if (tab === "themes") taxonomyForm("theme");
    else if (tab === "categories") taxonomyForm("category");
    else affirmationForm();
  }

  async function compressImage(file, maxW = 1600, quality = .82) {
    const url = await new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = rej;
      r.readAsDataURL(file);
    });
    const img = await new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = url;
    });
    const ratio = Math.min(1, maxW / img.width);
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * ratio);
    canvas.height = Math.round(img.height * ratio);
    canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", quality);
  }

  function getPtBrVoices() {
    if (!("speechSynthesis" in window)) return [];
    return voices.filter(v => String(v.lang || "").toLowerCase() === "pt-br");
  }

  function chosenVoice() {
    const ptbr = getPtBrVoices();
    const chosen = ptbr.find(v => v.voiceURI === state.settings.tts.voiceURI);
    return chosen || ptbr[0] || null;
  }

  function refreshVoices() {
    voices = "speechSynthesis" in window ? speechSynthesis.getVoices() : [];
    voices.sort((a, b) => String(a.name).localeCompare(String(b.name), "pt-BR"));
  }

  function speakText(text, title = "Leitura") {
    startQueue([{ text, title, subtitle: "TTS pt-BR" }]);
  }

  function startQueue(items) {
    if (!("speechSynthesis" in window)) return toast("TTS indisponível neste navegador.");
    const clean = items.map(x => ({ ...x, text: String(x.text || "").trim() })).filter(x => x.text);
    if (!clean.length) return toast("Não há texto para ler.");
    speechSynthesis.cancel();
    queue = clean;
    queueIndex = 0;
    playerState = { playing: true, paused: false, title: clean[0].title || "Leitura", subtitle: clean[0].subtitle || `${clean.length} item(ns)` };
    renderMiniPlayer();
    speakCurrent();
  }

  function speakCurrent() {
    if (!queue[queueIndex]) return stopTTS(true);
    const item = queue[queueIndex];
    const utter = new SpeechSynthesisUtterance(item.text);
    const voice = chosenVoice();
    if (voice) {
      utter.voice = voice;
      utter.lang = "pt-BR";
    } else {
      utter.lang = "pt-BR";
      if (!state._warnedVoice) {
        toast("Nenhuma voz pt-BR detectada; usando voz padrão do sistema.");
        state._warnedVoice = true;
      }
    }
    utter.rate = Number(state.settings.tts.rate || 1);
    utter.pitch = Number(state.settings.tts.pitch || 1);
    utter.volume = Number(state.settings.tts.volume || 1);
    utter.onstart = () => {
      playerState.playing = true;
      playerState.paused = false;
      playerState.title = item.title || "Leitura";
      playerState.subtitle = `${queueIndex + 1} de ${queue.length}`;
      renderMiniPlayer();
    };
    utter.onend = () => {
      queueIndex += 1;
      if (queueIndex < queue.length) speakCurrent();
      else stopTTS(true);
    };
    utter.onerror = () => {
      queueIndex += 1;
      if (queueIndex < queue.length) speakCurrent();
      else stopTTS(true);
    };
    currentUtterance = utter;
    speechSynthesis.speak(utter);
  }

  function pauseTTS() {
    if (!("speechSynthesis" in window)) return;
    speechSynthesis.pause();
    playerState.paused = true;
    renderMiniPlayer();
  }

  function resumeTTS() {
    if (!("speechSynthesis" in window)) return;
    speechSynthesis.resume();
    playerState.paused = false;
    renderMiniPlayer();
  }

  function stopTTS(done = false) {
    if ("speechSynthesis" in window) speechSynthesis.cancel();
    playerState = { playing: false, paused: false, title: "", subtitle: done ? "Concluído" : "" };
    queue = [];
    queueIndex = 0;
    currentUtterance = null;
    renderMiniPlayer();
  }

  function nextTTS() {
    if (!queue.length) return;
    speechSynthesis.cancel();
    queueIndex = Math.min(queue.length - 1, queueIndex + 1);
    speakCurrent();
  }

  function prevTTS() {
    if (!queue.length) return;
    speechSynthesis.cancel();
    queueIndex = Math.max(0, queueIndex - 1);
    speakCurrent();
  }

  function renderMiniPlayer() {
    if (!playerState.playing && !queue.length) {
      miniPlayer.hidden = true;
      return;
    }
    const pct = queue.length ? ((queueIndex + 1) / queue.length) * 100 : 0;
    miniPlayer.hidden = false;
    miniPlayer.innerHTML = `
      <div class="player-title">
        <b>${esc(playerState.title || "Leitura")}</b>
        <small>${esc(playerState.subtitle || "")}</small>
        <div class="progress"><span style="width:${pct}%"></span></div>
      </div>
      <div class="player-actions">
        <button class="icon-btn" data-player="prev" aria-label="Anterior">${hIcon("prev")}</button>
        ${playerState.paused
          ? `<button class="icon-btn" data-player="resume" aria-label="Continuar">${hIcon("play")}</button>`
          : `<button class="icon-btn" data-player="pause" aria-label="Pausar">${hIcon("pause")}</button>`}
        <button class="icon-btn" data-player="next" aria-label="Próxima">${hIcon("next")}</button>
        <button class="icon-btn" data-player="stop" aria-label="Parar">${hIcon("stop")}</button>
      </div>`;
  }

  function logPractice(type = "manual") {
    state.practiceLog.unshift({ id: id(), type, date: todayIso(), at: nowIso() });
    save();
    toast("Prática registrada.");
    render();
  }

  function startQuickSession() {
    const items = [
      ...state.affirmations.slice(0, 3).map(x => ({ text: x.text, title: x.title || "Afirmação", subtitle: "Prática rápida" })),
      ...state.insights.slice(0, 1).map(x => ({ text: `${x.title || ""}. ${x.text || ""}`, title: x.title || "Insight", subtitle: "Prática rápida" }))
    ];
    if (!items.length) return toast("Adicione afirmações ou insights para iniciar.");
    logPractice("rapida");
    startQueue(items);
  }

  function startDeepSession() {
    const belief = state.beliefs[0];
    const affs = state.affirmations.slice(0, 5);
    const items = [];
    if (belief) items.push({
      title: "Crença em revisão",
      subtitle: "Sessão profunda",
      text: `Crença atual: ${belief.current || ""}. Nova crença escolhida: ${belief.newBelief || ""}. Script de instalação: ${belief.script || ""}.`
    });
    affs.forEach(x => items.push({ text: x.text, title: x.title || "Afirmação", subtitle: "Sessão profunda" }));
    if (!items.length) return toast("Adicione crenças ou afirmações para iniciar.");
    logPractice("profunda");
    startQueue(items);
  }

  function startSlideshow() {
    if (!state.board.length) return toast("Adicione imagens ao Visual Board.");
    slideshowIndex = 0;
    showSlide();
  }

  function showSlide() {
    const item = state.board[slideshowIndex];
    openSheet("Slideshow", `${slideshowIndex + 1} de ${state.board.length}`, `
      <div class="slideshow">
        <img src="${item.image}" alt="${esc(item.title || "Imagem")}">
        <div>
          <h3>${esc(item.title || "Imagem")}</h3>
          <p>${esc(item.description || "")}</p>
          ${meta(item)}
        </div>
        <div class="card-actions">
          <button class="ghost-btn" id="slidePrev">${hIcon("prev")}Anterior</button>
          <button class="primary-btn" id="slideNext">${hIcon("next")}Próxima</button>
        </div>
      </div>`);
    $("#slidePrev").onclick = () => { slideshowIndex = (slideshowIndex - 1 + state.board.length) % state.board.length; showSlide(); };
    $("#slideNext").onclick = () => { slideshowIndex = (slideshowIndex + 1) % state.board.length; showSlide(); };
  }

  function exportAll() {
    const blob = new Blob([JSON.stringify({ exportedAt: nowIso(), version: APP_VERSION, state }, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `backup-painel-mental-v4-${todayIso()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function importJson(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        const incoming = parsed.state || parsed;
        const mode = confirm("OK = mesclar com dados atuais. Cancelar = substituir tudo.");
        if (mode) {
          state = mergeImport(state, incoming);
        } else {
          state = deepMerge(clone(DEFAULT_STATE), incoming);
        }
        save();
        toast("Importação concluída.");
        render();
      } catch {
        toast("Arquivo JSON inválido.");
      }
    };
    reader.readAsText(file);
  }

  function mergeImport(current, incoming) {
    const merged = deepMerge(clone(current), incoming);
    for (const key of ["affirmations", "beliefs", "insights", "board", "practiceLog"]) {
      const map = new Map();
      [...(current[key] || []), ...(incoming[key] || [])].forEach(x => map.set(x.id || id(), x));
      merged[key] = [...map.values()];
    }
    merged.themes = unique([...(current.themes || []), ...(incoming.themes || [])]);
    merged.categories = unique([...(current.categories || []), ...(incoming.categories || [])]);
    return merged;
  }

  function bind() {
    $("#bottomNav").addEventListener("click", e => {
      const b = e.target.closest("[data-route]");
      if (b) setRoute(b.dataset.route);
    });
    $("#fab").addEventListener("click", () => {
      if (route === "board") imageForm();
      else if (route === "library") quickAdd();
      else if (route === "practice") startQuickSession();
      else affirmationForm();
    });
    $("#closeSheet").addEventListener("click", closeSheet);
    sheetBackdrop.addEventListener("click", e => {
      if (e.target === sheetBackdrop) closeSheet();
    });

    document.addEventListener("click", e => {
      const routeJump = e.target.closest("[data-route-jump]");
      if (routeJump) return setRoute(routeJump.dataset.routeJump);

      const tab = e.target.closest("[data-library-tab]");
      if (tab) {
        state.ui.libraryTab = tab.dataset.libraryTab;
        save();
        renderLibrary();
        return;
      }

      const action = e.target.closest("[data-action]")?.dataset.action;
      if (action) {
        const map = {
          "quick-add": quickAdd,
          "add-affirmation": affirmationForm,
          "bulk-affirmations": bulkAffirmationsForm,
          "add-belief": beliefForm,
          "bulk-beliefs": bulkBeliefsForm,
          "add-insight": insightForm,
          "bulk-insights": bulkInsightsForm,
          "add-image": imageForm,
          "add-theme": () => taxonomyForm("theme"),
          "add-category": () => taxonomyForm("category"),
          "start-quick": startQuickSession,
          "start-deep": startDeepSession,
          "speak-filtered-affirmations": () => startQueue(filterItems(state.affirmations, activeFilters.affirmations).map(x => ({ text: x.text, title: x.title || "Afirmação", subtitle: "Afirmações filtradas" }))),
          "speak-beliefs": () => startQueue(filterItems(state.beliefs, activeFilters.beliefs).map(x => ({ text: `Crença atual: ${x.current || ""}. Nova crença: ${x.newBelief || ""}. ${x.script || ""}`, title: x.title || "Crença", subtitle: "Crenças filtradas" }))),
          "start-slideshow": startSlideshow,
          "night-session": () => { state.settings.theme = "dark"; state.settings.tts.rate = .82; save(); startDeepSession(); },
          "log-practice": () => logPractice("manual"),
          "speak-today": () => {
            const x = randomOf(state.affirmations) || randomOf(state.beliefs) || randomOf(state.insights);
            if (!x) return toast("Adicione conteúdo para ouvir.");
            speakText(x.text || `${x.current || ""}. ${x.newBelief || ""}` || x.title, x.title || "Destaque");
          },
          "test-tts": () => speakText("Esta é uma leitura de teste em português do Brasil.", "Teste de voz"),
          "export-all": exportAll,
          "import-json": () => $("#importFile")?.click(),
          "wipe": () => {
            if (confirm("Apagar todos os dados locais? Esta ação não pode ser desfeita.")) {
              localStorage.removeItem(KEY);
              state = clone(DEFAULT_STATE);
              stopTTS();
              save();
              render();
              toast("Dados apagados.");
            }
          }
        };
        map[action]?.();
      }

      const player = e.target.closest("[data-player]")?.dataset.player;
      if (player === "pause") pauseTTS();
      if (player === "resume") resumeTTS();
      if (player === "stop") stopTTS();
      if (player === "next") nextTTS();
      if (player === "prev") prevTTS();

      const speakAff = e.target.closest("[data-speak-affirmation]")?.dataset.speakAffirmation;
      if (speakAff) {
        const x = state.affirmations.find(i => i.id === speakAff);
        if (x) speakText(x.text, x.title || "Afirmação");
      }
      const speakBelief = e.target.closest("[data-speak-belief]")?.dataset.speakBelief;
      if (speakBelief) {
        const x = state.beliefs.find(i => i.id === speakBelief);
        if (x) speakText(`Crença atual: ${x.current || ""}. Nova crença escolhida: ${x.newBelief || ""}. ${x.script || ""}`, x.title || "Crença");
      }
      const speakInsight = e.target.closest("[data-speak-insight]")?.dataset.speakInsight;
      if (speakInsight) {
        const x = state.insights.find(i => i.id === speakInsight);
        if (x) speakText(`${x.title || ""}. ${x.text || ""}`, x.title || "Insight");
      }

      const fav = e.target.closest("[data-fav]")?.dataset.fav;
      if (fav) {
        const [arr, itemId] = fav.split(":");
        const item = state[arr]?.find(x => x.id === itemId);
        if (item) item.favorite = !item.favorite;
        save(); render();
      }

      const edit = e.target.closest("[data-edit]")?.dataset.edit;
      if (edit) {
        const [type, itemId] = edit.split(":");
        if (type === "affirmation") affirmationForm(state.affirmations.find(x => x.id === itemId));
        if (type === "belief") beliefForm(state.beliefs.find(x => x.id === itemId));
        if (type === "insight") insightForm(state.insights.find(x => x.id === itemId));
        if (type === "image") imageForm(state.board.find(x => x.id === itemId));
      }

      const del = e.target.closest("[data-del]")?.dataset.del;
      if (del) {
        const [arr, itemId] = del.split(":");
        if (confirm("Excluir este item?")) {
          state[arr] = state[arr].filter(x => x.id !== itemId);
          save(); render(); toast("Item excluído.");
        }
      }

      const viewImg = e.target.closest("[data-view-image]")?.dataset.viewImage;
      if (viewImg) {
        const idx = state.board.findIndex(x => x.id === viewImg);
        if (idx >= 0) { slideshowIndex = idx; showSlide(); }
      }

      const taxFilter = e.target.closest("[data-tax-filter]")?.dataset.taxFilter;
      if (taxFilter) {
        const [type, name] = taxFilter.split(":");
        activeFilters.affirmations[type] = name;
        state.ui.libraryTab = "affirmations";
        save(); renderLibrary();
      }

      const taxDelete = e.target.closest("[data-tax-delete]")?.dataset.taxDelete;
      if (taxDelete) {
        const [type, name] = taxDelete.split(":");
        if (confirm(`Excluir ${type === "theme" ? "tema" : "categoria"}? Os itens não serão apagados.`)) {
          if (type === "theme") state.themes = state.themes.filter(x => x !== name);
          if (type === "category") state.categories = state.categories.filter(x => x !== name);
          allItems().forEach(x => { if (x[type] === name) x[type] = ""; });
          save(); render();
        }
      }

      const color = e.target.closest("[data-color]")?.dataset.color;
      if (color) { state.settings.primary = color; save(); render(); }
    });

    document.addEventListener("input", e => {
      const q = e.target.closest("[data-filter-q]");
      if (q) {
        activeFilters[q.dataset.filterQ].q = q.value;
        render();
      }
      if (e.target.id === "globalSearch") {
        activeFilters.global = e.target.value;
        renderLibrary();
      }
      if (e.target.id === "intensityInput") $("#intLabel").textContent = e.target.value;

      const settingIds = {
        appNameField: ["appName"],
        subtitleField: ["subtitle"],
        openingField: ["opening"],
        fontScaleField: ["fontScale"],
        ttsRateField: ["tts", "rate"],
        ttsPitchField: ["tts", "pitch"],
        ttsVolumeField: ["tts", "volume"]
      };
      const path = settingIds[e.target.id];
      if (path) {
        if (path.length === 1) state.settings[path[0]] = e.target.type === "range" ? Number(e.target.value) : e.target.value;
        else state.settings[path[0]][path[1]] = Number(e.target.value);
        save();
      }
    });

    document.addEventListener("change", e => {
      const select = e.target.closest("[data-filter-select]");
      if (select) {
        const [kind, field] = select.dataset.filterSelect.split(":");
        activeFilters[kind][field] = select.value;
        render();
      }
      if (e.target.id === "themeField") { state.settings.theme = e.target.value; save(); render(); }
      if (e.target.id === "motionField") { state.settings.motion = e.target.value; save(); render(); }
      if (e.target.id === "ttsVoiceField") { state.settings.tts.voiceURI = e.target.value; save(); }
      if (e.target.id === "importFile" && e.target.files?.[0]) {
        importJson(e.target.files[0]);
        e.target.value = "";
      }
    });

    document.addEventListener("submit", async e => {
      e.preventDefault();
      const fd = new FormData(e.target);

      if (e.target.id === "affirmationForm") {
        const existing = state.affirmations.find(x => x.id === fd.get("id"));
        const item = {
          id: fd.get("id") || id(), title: fd.get("title").trim(), text: fd.get("text").trim(),
          theme: fd.get("theme").trim(), category: fd.get("category").trim(), tags: parseTags(fd.get("tags")),
          favorite: fd.get("favorite") === "on", createdAt: existing?.createdAt || nowIso(), updatedAt: nowIso()
        };
        if (!item.text) return toast("Informe o texto.");
        addTax(item);
        state.affirmations = existing ? state.affirmations.map(x => x.id === item.id ? item : x) : [item, ...state.affirmations];
        save(); closeSheet(); toast("Afirmação salva."); setRoute("library");
      }

      if (e.target.id === "bulkAffirmationsForm") {
        const chunks = splitBulk(fd.get("bulk"), fd.get("mode"));
        const theme = fd.get("theme").trim(), category = fd.get("category").trim(), tags = parseTags(fd.get("tags"));
        const now = nowIso();
        const items = chunks.map(text => ({ id: id(), title: text.slice(0, 54), text, theme, category, tags, favorite: false, createdAt: now, updatedAt: now }));
        items.forEach(addTax);
        state.affirmations = [...items, ...state.affirmations];
        save(); closeSheet(); toast(`${items.length} afirmação(ões) importada(s).`); renderLibrary();
      }

      if (e.target.id === "beliefForm") {
        const existing = state.beliefs.find(x => x.id === fd.get("id"));
        const item = {
          id: fd.get("id") || id(), title: fd.get("title").trim(), type: fd.get("type"),
          current: fd.get("current").trim(), newBelief: fd.get("newBelief").trim(), trigger: fd.get("trigger").trim(),
          root: fd.get("root").trim(), evidenceOld: fd.get("evidenceOld").trim(), evidenceNew: fd.get("evidenceNew").trim(),
          script: fd.get("script").trim(), intensity: Number(fd.get("intensity") || 5),
          theme: fd.get("theme").trim(), category: fd.get("category").trim(), tags: parseTags(fd.get("tags")),
          favorite: fd.get("favorite") === "on", createdAt: existing?.createdAt || nowIso(), updatedAt: nowIso()
        };
        if (!item.current && !item.newBelief) return toast("Informe a crença.");
        addTax(item);
        state.beliefs = existing ? state.beliefs.map(x => x.id === item.id ? item : x) : [item, ...state.beliefs];
        save(); closeSheet(); toast("Crença salva."); renderLibrary();
      }

      if (e.target.id === "bulkBeliefsForm") {
        const lines = splitBulk(fd.get("bulk"), "lines");
        const theme = fd.get("theme").trim(), category = fd.get("category").trim(), tags = parseTags(fd.get("tags"));
        const now = nowIso();
        const items = lines.map(line => {
          const [oldB, newB = ""] = line.split("=>").map(x => x.trim());
          return { id: id(), title: oldB.slice(0, 54), type: "transicao", current: oldB, newBelief: newB, trigger: "", root: "", evidenceOld: "", evidenceNew: "", script: newB, intensity: 5, theme, category, tags, favorite: false, createdAt: now, updatedAt: now };
        });
        items.forEach(addTax);
        state.beliefs = [...items, ...state.beliefs];
        save(); closeSheet(); toast(`${items.length} crença(s) importada(s).`); renderLibrary();
      }

      if (e.target.id === "insightForm") {
        const existing = state.insights.find(x => x.id === fd.get("id"));
        const item = {
          id: fd.get("id") || id(), title: fd.get("title").trim(), text: fd.get("text").trim(),
          theme: fd.get("theme").trim(), category: fd.get("category").trim(), tags: parseTags(fd.get("tags")),
          favorite: fd.get("favorite") === "on", createdAt: existing?.createdAt || nowIso(), updatedAt: nowIso()
        };
        if (!item.title && !item.text) return toast("Informe o insight.");
        addTax(item);
        state.insights = existing ? state.insights.map(x => x.id === item.id ? item : x) : [item, ...state.insights];
        save(); closeSheet(); toast("Insight salvo."); renderLibrary();
      }

      if (e.target.id === "bulkInsightsForm") {
        const chunks = splitBulk(fd.get("bulk"), fd.get("mode"));
        const theme = fd.get("theme").trim(), category = fd.get("category").trim(), tags = parseTags(fd.get("tags"));
        const now = nowIso();
        const items = chunks.map(text => ({ id: id(), title: text.slice(0, 54), text, theme, category, tags, favorite: false, createdAt: now, updatedAt: now }));
        items.forEach(addTax);
        state.insights = [...items, ...state.insights];
        save(); closeSheet(); toast(`${items.length} insight(s) importado(s).`); renderLibrary();
      }

      if (e.target.id === "imageForm") {
        const existing = state.board.find(x => x.id === fd.get("id"));
        const file = fd.get("image");
        let image = existing?.image || "";
        if (file && file.size) image = await compressImage(file);
        if (!image) return toast("Escolha uma imagem.");
        const item = {
          id: fd.get("id") || id(), title: fd.get("title").trim(), description: fd.get("description").trim(),
          image, theme: fd.get("theme").trim(), category: fd.get("category").trim(), tags: parseTags(fd.get("tags")),
          favorite: fd.get("favorite") === "on", createdAt: existing?.createdAt || nowIso(), updatedAt: nowIso()
        };
        addTax(item);
        state.board = existing ? state.board.map(x => x.id === item.id ? item : x) : [item, ...state.board];
        save(); closeSheet(); toast("Imagem salva."); setRoute("board");
      }

      if (e.target.id === "taxonomyForm") {
        const name = fd.get("name").trim();
        const type = e.target.dataset.type;
        if (!name) return toast("Informe o nome.");
        if (type === "theme" && !state.themes.includes(name)) state.themes.push(name);
        if (type === "category" && !state.categories.includes(name)) state.categories.push(name);
        save(); closeSheet(); toast("Criado."); renderLibrary();
      }
    });

    window.addEventListener("beforeinstallprompt", e => {
      e.preventDefault();
      // Intencionalmente discreto: instalação pode ser adicionada em Ajustes no futuro.
    });

    if ("speechSynthesis" in window) {
      refreshVoices();
      speechSynthesis.onvoiceschanged = () => {
        refreshVoices();
        if (route === "settings") renderSettings();
      };
    }
  }

  async function registerSW() {
    if ("serviceWorker" in navigator) {
      try { await navigator.serviceWorker.register("./sw.js"); }
      catch (err) { console.warn("Service Worker não registrado:", err); }
    }
  }

  applySettings();
  bind();
  render();
  registerSW();
})();
